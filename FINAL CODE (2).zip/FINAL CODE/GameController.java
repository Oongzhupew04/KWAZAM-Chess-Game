import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class GameController implements ActionListener   
{
    private GameModel model;     //Composition or Aggregation
    private GameView view;       //Composition or Aggregation
    private int row = 8;
    private int column = 5;
    private int x, y;
    private int oldX, oldY;
    private int turn = 0;
    private boolean firstButton = true;
    private Color originalColor;
    
    GameController(GameModel model, GameView view)
    {
        this.model = model;
        this.view = view;
    }

    public void actionPerformed(ActionEvent event)     //Polymorphism        //This function implements all button's and timer's action listener
    {
        JButton button = null;
        Timer sourceTimer = null;
        //Mok Wenkee
        if (event.getSource() instanceof JButton)     //If event is from button
        {
            button = (JButton) event.getSource();
        }
        else if (event.getSource() instanceof Timer)   //If event is from timer
        {
            sourceTimer = (Timer)event.getSource();
        }

        //Mok Wenkee     //For timer's action
        if (sourceTimer == view.getTimer())     //Remaining time timer
        {
            if (view.getElapsedTime() > 0)      //Remaining time more than 0
            {
                view.setElapsedTimeDecrement();
                int minutes = view.getElapsedTime() / 60;
                int seconds = view.getElapsedTime() % 60;
                view.getTimerLabel().setText("Remaining Time: " + String.format("%02d:%02d", minutes, seconds));
            } 
            else                                 ////if remaining time less than 0, skip the player's turn and turn the board
            {
                view.resetTimer();
                view.startTimer();
                turn++;
                if(turn%2 == 0)
                {
                    model.SwitchPieceType();
                }

                view.updatePiece(model.getPieceType(), turn);
                view.rotateBoard();
                model.setBoard(view.getBoard());
                view.updatePiece(model.getPieceType(), turn);
            }
        }
        else if(sourceTimer == view.getTimer2())       //Duration timer
        {
            view.setElapsedTime2Increment();
            int minutes = view.getElapsedTime2() / 60;
            int seconds = view.getElapsedTime2() % 60;
            view.getTimerLabel2().setText("Duration: " + String.format("%02d:%02d", minutes, seconds));
        }
        

        if(button == view.getNewGame())     //Mok Wenkee   //For button's action
        {
            model.InitializeBoard();
            turn = 0;
            view.updatePiece(model.getPieceType(), turn);
            view.setChessInterfaceTrue();
            view.setMenuInterfaceFalse();
            view.addResume();
            view.resetTimer();
            view.startTimer();
            view.resetTimer2();
            view.startTimer2();
        }
        else if(button == view.getSave())
        {
            model.setElapsedTime(view.getElapsedTime2());
            model.saveGame(turn);
            JOptionPane.showMessageDialog(null, "Game Saved");
        }
        else if(button == view.getLoadGame())
        {
            int[] gameState = model.loadGame();
            turn = gameState[0];
            int elapsedTime2 = gameState[1];
            view.updatePiece(model.getPieceType(), turn);
            view.setChessInterfaceTrue();
            view.setMenuInterfaceFalse();
            view.setElapsedTime(elapsedTime2);
            view.startTimer();
            view.startTimer2();
        }
        else if(button == view.getGameRules())
        {
            view.gameRulesFrame();
        }
        else if(button == view.getRestartGame())
        {
            model.InitializeBoard();
            turn = 0;
            view.updatePiece(model.getPieceType(), turn);
            view.setChessInterfaceTrue();
            view.setMenuInterfaceFalse();
            view.resetTimer();
            view.startTimer();
            view.resetTimer2();
            view.startTimer2();
            view.getTypeLabel().setText("");
            view.getFromLabel().setText("");
            view.getMoveLabel().setText("");
        }
        else if(button == view.getBack())
        {
            view.setChessInterfaceFalse();
            view.setMenuInterfaceTrue(); 
            view.stopTimer();
            view.stopTimer2();
        }
        else if(button == view.getResume())
        {
            view.setMenuInterfaceFalse(); 
            view.setChessInterfaceTrue();
            view.startTimer();
            view.startTimer2();
        }
        else if(button != null)      //For all chess buttons
        {
            for(int i = 0; i < row; i++) {
                for(int j = 0; j < column; j++) {
                    if(view.getBoardButton(i, j) == button) {
                        x = i;
                        y = j;
                        break;
                    }
                }
            }
            
            
            if(firstButton) {     //Lim Tao Hong            //For the first click to select which chess piece to move
                if(model.getBoard(x, y) != null) 
                {
                    firstButton = false;
                    originalColor = view.getBoardButton(x, y).getBackground();
                    view.getBoardButton(x, y).setBackground(Color.YELLOW);
                    view.getMoveLabel().setText("");
                    view.getTypeLabel().setText("<html>Chess Piece selected : <br>" + view.getPieceType(x, y) + "</html>");
                    view.getFromLabel().setText("Old Position : (" + x + " , " + y + ")");
                }
                else if(model.getBoard(x, y) == null)
                {
                    view.getTypeLabel().setText("");
                    view.getFromLabel().setText("");
                    view.getMoveLabel().setText("");
                }
            }
            else                       //For the second click to select which location the chess piece will move to 
            {
                firstButton = true;
                for(int i = 0; i < row; i++) 
                {
                    for(int j = 0; j < column; j++) 
                    {
                        if(view.getBoardButton(i, j).getBackground() == Color.YELLOW) 
                        {
                            oldX = i;
                            oldY = j;
                            view.getBoardButton(i, j).setBackground(originalColor);
                            view.getMoveLabel().setText("New Position : (" + x + " , " + y + ")");
                            break;
                        }
                    }
                }
                
                if(model.getBoard(oldX, oldY).pieceMovement(oldX, oldY, x, y) && model.checkValidMove(oldX, oldY, x, y, turn))      //Sheah Ethan and Vincent Oong Zhu Pew   //If the conditions for the chess piece to move to the location selected are all true
                {
                    model.setBoard(x, y, model.getBoard(oldX, oldY));
                    model.setBoard(oldX, oldY, null);

                    view.resetTimer();
                    view.startTimer();
                    turn++;
                    if(turn%2 == 0)
                    {
                        model.SwitchPieceType();
                    }

                    view.updatePiece(model.getPieceType(), turn);
                    view.rotateBoard();
                    model.setBoard(view.getBoard());
                    view.updatePiece(model.getPieceType(), turn);

                    String game = model.GameOver();
                    if(!game.equals("Continue"))        //To check if both Sau are alive on the board
                    {
                        view.stopTimer();
                        view.stopTimer2();
                        JOptionPane.showMessageDialog(null, "GAME OVER !\n" + game + " TEAM WINS");
                        
                        
                        model.InitializeBoard();
                        turn = 0;
                        view.updatePiece(model.getPieceType(), turn);
                        view.resetTimer();
                        view.startTimer();
                        view.resetTimer2();
                        view.startTimer2();
                        view.getTypeLabel().setText("");
                        view.getFromLabel().setText("");
                        view.getMoveLabel().setText("");
                    }
                }
            }
        }
    }
}