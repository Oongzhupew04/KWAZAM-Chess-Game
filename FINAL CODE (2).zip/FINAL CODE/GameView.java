import javax.swing.*;
import javax.swing.border.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.image.BufferedImage;
import java.io.*;

class GameView extends JFrame
{
    private int row = 8;
    private int column = 5;
    private int turn = 0;
    private GameController controller;      //Composition or Aggregation
    private JFrame chessInterface;
    private JFrame gameRulesFrame;
    private JPanel board = new JPanel();
    private JPanel instruction = new JPanel();
    private JLabel type, from, move;
    private JPanel menu = new JPanel();
    private JButton [][] boardButton = new JButton[row][column];
    private String [][]pieceType = new String[row][column];
    private Icon RedRam, RedBiz, RedTor, RedXor, RedSau, RedRam2, RedSau2;
    private Icon BlueRam, BlueBiz, BlueTor, BlueXor, BlueSau, BlueRam2, BlueSau2;

    private JButton save, load, newGame, loadGame, gameRules, restartGame, back, resume;
    private JPanel buttonPanel = new JPanel();

    private Timer timer;               //For remaining time timer
    private int elapsedTime = 60;
    private JLabel timerLabel;
    
    private Timer timer2;              //For duration timer
    private int elapsedTime2 = 0;
    private JLabel timerLabel2;
    
    GameView()     //Lim Tao Hong
    {
        super("KWAZAM CHESS");
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        setLayout(new BorderLayout());

        ImageIcon icon = new ImageIcon("chess background.jpg");
        Image image = icon.getImage();
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        Image scaledImage = image.getScaledInstance(screenSize.width, screenSize.height, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);

        JLayeredPane layeredPane = new JLayeredPane();
        add(layeredPane, BorderLayout.CENTER);

        JPanel mainPanel = new JPanel();
        mainPanel.setOpaque(false); 
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS)); 
        
        iconLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        layeredPane.add(iconLabel, Integer.valueOf(0));
        mainPanel.setBounds(0, 0, screenSize.width, screenSize.height); 
        layeredPane.add(mainPanel, Integer.valueOf(1));

        

        JLabel chessGame = new JLabel("KWAZAM CHESS GAME");
        chessGame.setFont(new Font("Serif", Font.BOLD, 96));
        chessGame.setForeground(Color.WHITE);
        chessGame.setAlignmentX(Component.CENTER_ALIGNMENT); 
        
        buttonPanel.setBorder(new EmptyBorder(180, 0, 0, 0));
        buttonPanel.setBackground(new Color(0, 0, 0, 0));
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        
        newGame = new JButton("New Game");
        newGame.setFont(new Font("Arial", Font.BOLD, 46));
        newGame.setPreferredSize(new Dimension(360, 90));
        newGame.setBackground(new Color(201,147,90,255));
        newGame.setForeground(Color.WHITE);
        newGame.setBorder(new LineBorder(new Color(139,69,19,255), 10));
        buttonPanel.add(newGame);

        buttonPanel.add(Box.createRigidArea(new Dimension(50, 0)));
        
        loadGame = new JButton("Load Game");
        loadGame.setFont(new Font("Arial", Font.BOLD, 46));
        loadGame.setPreferredSize(new Dimension(360, 90));
        loadGame.setBackground(new Color(201,147,90,255));
        loadGame.setForeground(Color.WHITE);
        loadGame.setBorder(new LineBorder(new Color(139,69,19,255), 10));
        buttonPanel.add(loadGame);

        buttonPanel.add(Box.createRigidArea(new Dimension(50, 0)));
        
        gameRules = new JButton("Game Rules");
        gameRules.setFont(new Font("Arial", Font.BOLD, 46));
        gameRules.setPreferredSize(new Dimension(360, 90));
        gameRules.setBackground(new Color(201,147,90,255));
        gameRules.setForeground(Color.WHITE);
        gameRules.setBorder(new LineBorder(new Color(139,69,19,255), 10));
        buttonPanel.add(gameRules);

        buttonPanel.add(Box.createRigidArea(new Dimension(50, 0)));

        resume = new JButton("Resume Game");
        resume.setFont(new Font("Arial", Font.BOLD, 46));
        resume.setPreferredSize(new Dimension(360, 90));
        resume.setBackground(new Color(201,147,90,255));
        resume.setForeground(Color.WHITE);
        resume.setBorder(new LineBorder(new Color(139,69,19,255), 10));

        mainPanel.add(Box.createVerticalGlue()); 
        mainPanel.add(chessGame); 
        mainPanel.add(buttonPanel);
        mainPanel.add(Box.createVerticalGlue()); 


        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        timerLabel = new JLabel("Remaining Time: 00:60");
        timerLabel.setFont(new Font("Arial", Font.BOLD, 30));
        timerLabel.setForeground(Color.RED);
        instruction.add(timerLabel);
        
        
        
        chessInterface = new JFrame("KWAZAM CHESS GAME");
        chessInterface.setDefaultCloseOperation(EXIT_ON_CLOSE);
        chessInterface.setLayout(new GridLayout(1, 3));
        chessInterface.setMaximumSize(new Dimension(screenSize.width, 1000));
        chessInterface.setMinimumSize(new Dimension(1200, 800));
        chessInterface.setLocationRelativeTo(null);
        chessInterface.pack();

        Color brown = new Color(150, 75, 0);
        instruction.setBackground(brown);
        menu.setBackground(brown);
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));

        board.setLayout(new GridLayout(8, 5));
        chessInterface.add(instruction);
        chessInterface.add(board);
        chessInterface.add(menu);
        
        menu.add(Box.createVerticalGlue());
        
        timerLabel2 = new JLabel("Duration: 00:00");
        timerLabel2.setFont(new Font("Arial", Font.BOLD, 30));
        timerLabel2.setForeground(Color.WHITE);
        timerLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
        menu.add(timerLabel2);
        
        menu.add(Box.createRigidArea(new Dimension(0, 50)));
        
        restartGame = new JButton("Restart Game");
        restartGame.setFont(new Font("Arial", Font.BOLD, 46));
        restartGame.setBackground(new Color(201,147,90,255));
        restartGame.setForeground(Color.WHITE);
        restartGame.setBorder(new LineBorder(new Color(101,67,33), 10));
        restartGame.setAlignmentX(Component.CENTER_ALIGNMENT);
        menu.add(restartGame);
        
        menu.add(Box.createRigidArea(new Dimension(0, 10)));

        save = new JButton("Save Game");
        save.setFont(new Font("Arial", Font.BOLD, 46));
        save.setBackground(new Color(201,147,90,255));
        save.setForeground(Color.WHITE);
        save.setBorder(new LineBorder(new Color(101,67,33), 10));
        save.setAlignmentX(Component.CENTER_ALIGNMENT);
        menu.add(save);
        
        menu.add(Box.createRigidArea(new Dimension(0, 10)));

        back = new JButton("Back");
        back.setFont(new Font("Arial", Font.BOLD, 46));
        back.setBackground(new Color(201,147,90,255));
        back.setForeground(Color.WHITE);
        back.setBorder(new LineBorder(new Color(101,67,33), 10));
        back.setAlignmentX(Component.CENTER_ALIGNMENT);
        menu.add(back);
        
        menu.add(Box.createVerticalGlue());
        
        type = new JLabel();
        type.setFont(new Font("Ariel", Font.BOLD, 30));
        type.setForeground(Color.WHITE);
        type.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));
        instruction.add(type);
        
        from = new JLabel();
        from.setFont(new Font("Ariel", Font.BOLD, 30));
        from.setForeground(Color.WHITE);
        instruction.add(from);

        move = new JLabel();
        move.setFont(new Font("Ariel", Font.BOLD, 30));
        move.setForeground(Color.WHITE);
        instruction.add(move);

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                boardButton[i][j] = new JButton();
                board.add(boardButton[i][j]);
            }
        }
        
        pieceType[0] = new String[]{"RedTor", "RedBiz", "RedSau", "RedBiz", "RedXor"};
        pieceType[1] = new String[]{"RedRam", "RedRam", "RedRam", "RedRam", "RedRam"};
        pieceType[2] = new String[]{null, null, null, null, null};
        pieceType[3] = new String[]{null, null, null, null, null};
        pieceType[4] = new String[]{null, null, null, null, null};
        pieceType[5] = new String[]{null, null, null, null, null};
        pieceType[6] = new String[]{"BlueRam", "BlueRam", "BlueRam", "BlueRam", "BlueRam"};
        pieceType[7] = new String[]{"BlueXor", "BlueBiz", "BlueSau", "BlueBiz", "BlueTor"};

        if(turn == 0)
        {
            setPiece();
        }
        chessInterface.setVisible(false);
    }

    void setImage(int x, int y, String type, int turn)    //Lim Tao Hong    //This function sets chess image on chess board
    {
        ImageIcon image = new ImageIcon(getClass().getResource(type + ".png"));

        if(turn%2 == 1)
        {
            image = (ImageIcon)rotateIcon(image);
        }
        boardButton[x][y].setIcon(ImageResize(image, 90, 90));
    }

    void setPiece()      //Lim Tao Hong     //This function sets the chess piece object details
    {
        int colorSpot = 0;
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                if(pieceType[i][j] != null)
                {
                    setImage(i, j, pieceType[i][j], turn);
                }

                if(colorSpot%2 == 0)
                {
                    boardButton[i][j].setBackground(Color.BLACK);
                }
                else
                {
                    boardButton[i][j].setBackground(Color.WHITE);
                }
                colorSpot++;
            }
        }
    }

    void updatePiece(String[][] board, int turn)    //Lim Tao Hong    //This function sets the moved chess piece object details
    {
        int colorSpot = 0;
        pieceType = board;
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                if(colorSpot%2 == 0)
                {
                    boardButton[i][j].setBackground(Color.BLACK);
                }
                else
                {
                    boardButton[i][j].setBackground(Color.WHITE);
                }
                colorSpot++;
                
                String piece = board[i][j];
                if(piece == null)
                {
                    boardButton[i][j].setIcon(null);
                }
                else
                {
                    setImage(i, j, board[i][j], turn);
                }
            }
        }
    }
    
    private ImageIcon ImageResize(ImageIcon pic, int x, int y)     //Lim Tao Hong  //This function resize the chess image smaller to fit the chess board
    {
        Image img = pic.getImage();                                                
        Image resizedImage = img.getScaledInstance(x, y, Image.SCALE_SMOOTH);       
        return new ImageIcon(resizedImage);                                       
    }

    void rotateBoard()     //Lim Tao Hong    //This function rotates the board
    {
        String [][] board2 = new String[row][column];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                board2[row - i - 1][column - j - 1] = pieceType[i][j];
            }
        }

        pieceType = board2;
    }

    //Mok Wenkee     //Encapsulation
    public String[][] getBoard() {return pieceType;}
    public JButton getNewGame() {return newGame;}
    public JButton getSave() {return save;}
    public JButton getLoadGame() {return loadGame;}
    public JButton getGameRules() {return gameRules;}
    public JButton getRestartGame() {return restartGame;}
    public JButton getBack() {return back;}
    public JButton getResume() {return resume;}
    public JButton getBoardButton(int x, int y) {return boardButton[x][y];}
    public String getPieceType(int x, int y) {return pieceType[x][y];}
    
    public JLabel getTypeLabel() {return type;}
    public JLabel getFromLabel() {return from;}
    public JLabel getMoveLabel() {return move;}

    void setEventHandler(GameController controller)      //Mok Wenkee   //This function sets all button's and timer's action listener
    {
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                boardButton[i][j].addActionListener(controller);
            }
        }
        save.addActionListener(controller);
        newGame.addActionListener(controller);
        loadGame.addActionListener(controller);
        gameRules.addActionListener(controller);
        restartGame.addActionListener(controller);
        back.addActionListener(controller);
        resume.addActionListener(controller);
        timer = new Timer(1000, controller);
        timer2 = new Timer(1000, controller);
    }
    
    public void setChessInterfaceFalse()
    {
        chessInterface.setVisible(false);
    }
    
    public void setChessInterfaceTrue()
    {
        chessInterface.setVisible(true);
    }
    
    public void setMenuInterfaceFalse()
    {
        this.setVisible(false);
    }
    
    public void setMenuInterfaceTrue()
    {
        this.setVisible(true);
    }

    public void addResume()
    {
        buttonPanel.add(resume);
    }
    
    public Icon rotateIcon(Icon originalIcon) {     //Mok Wenkee      //This function rotates the chess image when the chess board rotates
        
        ImageIcon imageIcon = (ImageIcon) originalIcon;
        Image image = imageIcon.getImage();
        
        int width = image.getWidth(null);
        int height = image.getHeight(null);
        
        BufferedImage rotatedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        
        Graphics2D g2d = rotatedImage.createGraphics();
        
        g2d.rotate(Math.PI, width / 2, height / 2);  
        g2d.drawImage(image, 0, 0, null); 
        
        g2d.dispose();
        
        return new ImageIcon(rotatedImage);
    }
    
    public void gameRulesFrame()     //Lim Tao Hong    //This creates the frame for Game Rules
    {
        gameRulesFrame = new JFrame("Game Rules");
        gameRulesFrame.setPreferredSize(new Dimension(534, 756));
        gameRulesFrame.pack();
        ImageIcon icon = new ImageIcon("game rules.png");
        Image image = icon.getImage();
        Dimension frameSize = gameRulesFrame.getSize();  
        int width = (frameSize.width) - 17;
        int height = (frameSize.height) - 40;
        Image scaledImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        gameRulesFrame.add(iconLabel);
        gameRulesFrame.setLocationRelativeTo(null);
        gameRulesFrame.setVisible(true);
        gameRulesFrame.setResizable(false);
    }

    //Encapsulation   //Lim Tao Hong
    public Timer getTimer() {return timer;}
    public int getElapsedTime() {return elapsedTime;}
    public void setElapsedTimeDecrement() {elapsedTime--;}
    public JLabel getTimerLabel() {return timerLabel;}
    
    public void startTimer() {timer.start();}

    public void resetTimer()     //Lim Tao Hong
    {
        stopTimer();
        elapsedTime = 60;
        timerLabel.setText("Remaining Time: 00:60");
    }

    public void stopTimer()      //Lim Tao Hong
    {
        if(timer != null)
        {
            timer.stop();
        }
    }

    //Encapsulation    //Lim Tao Hong
    public Timer getTimer2() {return timer2;}
    public int getElapsedTime2() {return elapsedTime2;}
    public void setElapsedTime2Increment() {elapsedTime2++;}
    public JLabel getTimerLabel2() {return timerLabel2;}
    
    public void startTimer2() {timer2.start();}

    public void resetTimer2()      //Lim Tao Hong
    {
        stopTimer2();
        elapsedTime2 = 0;
        timerLabel2.setText("Duration: 00:00");
    }

    public void stopTimer2()      //Lim Tao Hong
    {
        if(timer2 != null)
        {
            timer2.stop();
        }
    }

    public void setElapsedTime(int elapsedTime2)     //Lim Tao Hong
    {
        this.elapsedTime2 = elapsedTime2;
        int minutes = elapsedTime2 / 60;
        int seconds = elapsedTime2 % 60;
        timerLabel2.setText("Duration: " + String.format("%02d:%02d", minutes, seconds));
    }
}