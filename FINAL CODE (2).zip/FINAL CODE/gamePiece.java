import javax.swing.*;

public abstract class gamePiece
    {
        abstract boolean pieceMovement(int x, int y, int x2, int y2);
        abstract int getX();
        abstract int getY();
        abstract void setPosition(int x, int y);
        abstract String getColor();
        abstract String getType();
    }