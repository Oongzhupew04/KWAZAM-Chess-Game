import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class GameModel
{
    private static int row = 8;
    private static int column = 5;
    private gamePiece [][] board = new gamePiece[row][column];
    private String [][] pieceType = new String[row][column];
    private int elapsedTime;

    GameModel()
    {
        InitializeBoard();
    }

    public int getElapsedTime()     //Encapsulation
    {
        return elapsedTime;
    }

    public void setElapsedTime(int time)     //Encapsulation
    {
        this.elapsedTime = time;
    }

    //Ram
    class Ram extends gamePiece  //Sheah Ethan    Subclassing
    {
        private String color;
        private int x, y;
        private String type;
        private boolean reverse = false;
        private MovementStrategy movement;

        Ram(int x, int y, String group)
        {
            this.x = x;
            this.y = y;
            this.color = group;
            this.movement = new RamMovement();     //Composition or Aggregation

            if(this.color.equals("red"))
            {
                type =  "RedRam";
            }
            else if(this.color.equals("blue"))
            {
                type =  "BlueRam";
            }
        }

        public boolean pieceMovement(int oldX, int oldY, int moveX, int moveY)
        {
            if(movement.canMove(oldX, oldY, moveX, moveY))
            {
                if(moveX == 0)
                {
                    if(color.equals("red"))
                    {
                        type =  "RedRam2";
                    }
                    else
                    {
                        type =  "BlueRam2";
                    }
                }
                else if(moveX == 7)
                {
                    if(color.equals("red"))
                    {
                        type =  "RedRam";
                    }
                    else
                    {
                        type =  "BlueRam";
                    }
                }

                this.x = moveX;
                this.y = moveY;
                return true;
            }
            else
            {
                return false;
            }
        }

        //Encapsulation
        public int getX()
        {
            return this.x;
        }

        public int getY()
        {
            return this.y;
        }

        public void setPosition(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public String getColor()
        {
            return this.color;
        }

        public String getType()
        {
            return this.type;
        }
    }

    //Biz
    class Biz extends gamePiece   //Sheah Ethan    Subclassing
    {
        private String color;
        private int x, y;
        private String type;
        private MovementStrategy movement;

        Biz(int x, int y, String group)
        {
            this.x = x;
            this.y = y;
            this.color = group;
            this.movement = new BizMovement();     //Composition or Aggregation
            
            if(this.color.equals("red"))
            {
                type =  "RedBiz";
            }
            else if(this.color.equals("blue"))
            {
                type =  "BlueBiz";
            }
        }

        public boolean pieceMovement(int oldX, int oldY, int moveX, int moveY)
        {
            if(movement.canMove(oldX, oldY, moveX, moveY))
            {
                this.x = moveX;
                this.y = moveY;
                return true;
            }
            else
            {
                return false;
            }
        }

        //Encapsulation
        public int getX()
        {
            return this.x;
        }

        public int getY()
        {
            return this.y;
        }

        public void setPosition(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public String getColor()
        {
            return this.color;
        }

        public String getType()
        {
            return this.type;
        }
    }

    //Tor
    class Tor extends gamePiece   //Sheah Ethan    Subclassing
    {
        private String color;
        private int x, y;
        private String type;
        private MovementStrategy movement;

        Tor(int x, int y, String group)
        {
            this.x = x;
            this.y = y;
            this.color = group;
            this.movement = new TorMovement();     //Composition or Aggregation
            
            if(this.color.equals("red"))
            {
                type =  "RedTor";
            }
            else if(this.color.equals("blue"))
            {
                type =  "BlueTor";
            }
        }

        public boolean pieceMovement(int oldX, int oldY, int moveX, int moveY)
        {
            if(movement.canMove(oldX, oldY, moveX, moveY))
            {
                this.x = moveX;
                this.y = moveY;
                return true;
            }
            else
            {
                return false;
            }
        }

        //Encapsulation
        public int getX()
        {
            return this.x;
        }

        public int getY()
        {
            return this.y;
        }

        public void setPosition(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public String getColor()
        {
            return this.color;
        }

        public String getType()
        {
            return this.type;
        }

        public void changeType(int switchX, int switchY, String switchColor)
        {
            if(switchColor.equals("red"))
            {
                board[switchX][switchY] = new Xor(switchX, switchY, switchColor);
            }
            else
            {
                board[switchX][switchY] = new Xor(switchX, switchY, switchColor);
            }
        }
    }

    //Xor
    class Xor extends gamePiece   //Sheah Ethan    Subclassing
    {
        private String color;
        private int x, y;
        private String type;
        private MovementStrategy movement;

        Xor(int x, int y, String group)
        {
            this.x = x;
            this.y = y;
            this.color = group;
            this.movement = new XorMovement();      //Composition or Aggregation

            if(this.color.equals("red"))
            {
                type =  "RedXor";
            }
            else if(this.color.equals("blue"))
            {
                type =  "BlueXor";
            }
        }

        public boolean pieceMovement(int oldX, int oldY, int moveX, int moveY)
        {
            if(movement.canMove(oldX, oldY, moveX, moveY))
            {
                this.x = moveX;
                this.y = moveY;
                return true;
            }
            else
            {
                return false;
            }
        }

        //Encapsulation
        public int getX()
        {
            return this.x;
        }

        public int getY()
        {
            return this.y;
        }

        public void setPosition(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public String getColor()
        {
            return this.color;
        }

        public String getType()
        {
            return this.type;
        }

        public void changeType(int switchX, int switchY, String switchColor)
        {
            if(switchColor.equals("red"))
            {
                board[switchX][switchY] = new Tor(switchX, switchY, switchColor);
            }
            else
            {
                board[switchX][switchY] = new Tor(switchX, switchY, switchColor);
            }
        }
    }

    //Sau
    class Sau extends gamePiece   //Sheah Ethan    Subclassing
    {
        private String color;
        private int x, y;
        private String type;
        private MovementStrategy movement;

        Sau(int x, int y, String group)
        {
            this.x = x;
            this.y = y;
            this.color = group;
            this.movement = new SauMovement();    //Composition or Aggregation
            
            if(this.color.equals("red"))
            {
                type =  "RedSau";
            }
            else if(this.color.equals("blue"))
            {
                type =  "BlueSau";
            }
        }

        public boolean pieceMovement(int oldX, int oldY, int moveX, int moveY)
        {
            if(movement.canMove(oldX, oldY, moveX, moveY))
            {
                this.x = moveX;
                this.y = moveY;
                return true;
            }
            else
            {
                return false;
            }
        }

        //Encapsulation
        public int getX()
        {
            return this.x;
        }

        public int getY()
        {
            return this.y;
        }

        public void setPosition(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public String getColor()
        {
            return this.color;
        }
        
        public String getType()
        {
            return this.type;
        }
    }

    interface MovementStrategy   //Sheah Ethan    Design Pattern: Strategy
    {
        boolean canMove(int x, int y, int moveX, int moveY);
    }

    class RamMovement implements MovementStrategy   //Sheah Ethan    Subclassing    Delegation
    {
        private boolean reverse = false;

        public boolean canMove(int oldX, int oldY, int moveX, int moveY)
        {
            if(oldX == 0)
            {
                reverse = true;
            }
            else if(oldX == 7)
            {
                reverse = false;
            }

            if(!reverse)
            {
                int Rx = moveX - oldX;
                return Rx == -1 && moveY == oldY;
            }
            else
            {              
                int Rx = moveX - oldX;
                return Rx == 1 && moveY == oldY;
            }
        }
    }

    class BizMovement implements MovementStrategy   //Sheah Ethan     Subclassing    Delegation
    {
        public boolean canMove(int oldX, int oldY, int moveX, int moveY)
        {
            int Lx = Math.abs(moveX - oldX);
            int Ly = Math.abs(moveY - oldY);

            if((Lx == 2 && Ly == 1) || (Lx == 1 && Ly == 2))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    class TorMovement implements MovementStrategy   //Sheah Ethan     Subclassing   Delegation
    {
        public boolean canMove(int oldX, int oldY, int moveX, int moveY)
        {
            int minX = Math.min(moveX , oldX);
            int minY = Math.min(moveY , oldY);
            int maxX = Math.max(moveX , oldX);
            int maxY = Math.max(moveY , oldY);

            if(oldX == moveX || oldY == moveY)
            {
                for(int i = minY + 1; i < maxY; i++)
                {
                    if(board[moveX][i] != null)
                    {
                        return false;
                    }
                }

                for(int i = maxY - 1; i > minY; i--)
                {
                    if(board[moveX][i] != null)
                    {
                        return false;
                    }
                }

                for(int i = minX + 1; i < maxX; i++)
                {
                    if(board[i][moveY] != null)
                    {
                        return false;
                    }
                }

                for(int i = maxX - 1; i > minX; i--)
                {
                    if(board[i][moveY] != null)
                    {
                        return false;
                    }
                }

                return true;
            }
            else
            {
                return false;
            }
        }
    }

    class XorMovement implements MovementStrategy   //Sheah Ethan    Subclassing   Delegation
    {
        public boolean canMove(int oldX, int oldY, int moveX, int moveY)
        {
            int Xx = Math.abs(moveX - oldX);
            int Xy = Math.abs(moveY - oldY);

            int Cx = Integer.compare(moveX, oldX);
            int Cy = Integer.compare(moveY, oldY);

            int Sx = oldX + Cx;
            int Sy = oldY + Cy;

            if(Xx == Xy)
            {
                while(Sx != moveX && Sy != moveY)
                {
                    if(board[Sx][Sy] != null)
                    {
                        return false;
                    }
                    Sx += Cx;
                    Sy += Cy;
                }

                return true;
            }
            else
            {
                return false;
            }
        }
    }

    class SauMovement implements MovementStrategy   //Sheah Ethan    Subclassing   Delegation
    {
        public boolean canMove(int oldX, int oldY, int moveX, int moveY)
        {
            int Sx = Math.abs(moveX - oldX);
            int Sy = Math.abs(moveY - oldY);
            if((Sx == 0 && Sy == 1) || (Sx == 1 && Sy == 0) || (Sx == 1 && Sy == 1))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    void InitializeBoard()    //Vincent Oong Zhu Pew
    {
        for (int i = 2; i < 6; i++)
        {
            for (int j = 0; j < column; j++)
            {
                board[i][j] = null;
            }
        }

        board[1][0] = new Ram(1, 0, "red");
        board[1][1] = new Ram(1, 1, "red");
        board[1][2] = new Ram(1, 2, "red");
        board[1][3] = new Ram(1, 3, "red");
        board[1][4] = new Ram(1, 4, "red");
        board[0][1] = new Biz(0, 1, "red");
        board[0][3] = new Biz(0, 3, "red");
        board[0][0] = new Tor(0, 0, "red");
        board[0][4] = new Xor(0, 4, "red");
        board[0][2] = new Sau(0, 2, "red");

        board[6][0] = new Ram(6, 0, "blue");
        board[6][1] = new Ram(6, 1, "blue");
        board[6][2] = new Ram(6, 2, "blue");
        board[6][3] = new Ram(6, 3, "blue");
        board[6][4] = new Ram(6, 4, "blue");
        board[7][1] = new Biz(7, 1, "blue");
        board[7][3] = new Biz(7, 3, "blue");
        board[7][4] = new Tor(7, 4, "blue");
        board[7][0] = new Xor(7, 0, "blue");
        board[7][2] = new Sau(7, 2, "blue");
    }

    boolean checkValidMove(int firstX, int firstY, int secondX, int secondY, int turn)    //Vincent Oong Zhu Pew
    {
        turn %= 2;
        String color;
        if(turn == 0)
        {
            color = "blue";
        }
        else
        {
            color = "red";
        }

        if(board[firstX][firstY].getColor().equals(color))
        {
            if(board[secondX][secondY] != null)
            {
                String chess = board[firstX][firstY].getColor();
                String target = board[secondX][secondY].getColor();

                if(chess.equals(target))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else if(board[secondX][secondY] == null)
            {
                return true;
            }
        }
        return false;
    }

    void SwitchPieceType()    //Vincent Oong Zhu Pew
    {
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                if(board[i][j] instanceof Tor)
                {   
                    Tor chess = (Tor)board[i][j];
                    chess.changeType(i, j, board[i][j].getColor());
                }
                else if(board[i][j] instanceof Xor)
                {   
                    Xor chess = (Xor)board[i][j];
                    chess.changeType(i, j, board[i][j].getColor());
                }
            }
        }
    }

    String GameOver()    //Vincent Oong Zhu Pew
    {
        int numOfSau = 0;
        int x = 0, y = 0;
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                if(board[i][j] instanceof Sau)
                {
                    numOfSau++;
                    x = i;
                    y = j;
                }
            }
        }
        
        if(numOfSau == 2)
        {
            return "Continue";
        }
        else
        {
            String teamWin = board[x][y].getColor();
            return teamWin.toUpperCase();
        }
    }

    void saveGame(int turn)   //Vincent Oong Zhu Pew
    {
        File file = new File("Save.txt");

        try(PrintWriter writer = new PrintWriter(file))
        {
            writer.println("Turn : " + turn);
            writer.println("Elapsed Time: " + elapsedTime);

            for(int i = 0; i < row; i++)
            {
                for(int j = 0; j < column; j++)
                {
                    if(board[i][j] != null)
                    {
                        writer.print(board[i][j].getType() + " ");
                    }
                    else
                    {
                        writer.print("Empty ");
                    }
                }

                writer.println();
            }

        } catch (Exception e)
        {
            System.out.println("Error ! Cant Save Game !");
        }
    }

    public String[][] getPieceType()   //Vincent Oong Zhu Pew
    {
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                if (board[i][j] != null) 
                {
                    pieceType[i][j] = board[i][j].getType();
                } 
                else 
                {
                    pieceType[i][j] = null;
                }
            }
        }

        return pieceType;
    }
    
    public gamePiece getBoard(int x, int y) {return board[x][y];}     //Vincent Oong Zhu Pew
    public void setBoard(int x, int y, gamePiece piece) {board[x][y] = piece;}

    public void setBoard(String[][] chessType)    //Vincent Oong Zhu Pew    //Sets the initial board
    {
        String chess;
        int oldX = 0;
        int oldY = 0;
        int moveX = 0;
        int moveY = 0;

        pieceType = chessType;
    
        gamePiece [][] board2 = new gamePiece[row][column];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < column; j++)
            {
                board2[row - i - 1][column - j - 1] = board[i][j];
            }
        }

        board = board2;
    }

    public void createPiece(int x, int y, String type)    //Vincent Oong Zhu Pew     //Polymorphism     //Creates chess piece
    {
        String color;
        if(type.contains("Red"))
        {
            color = "red";
        }
        else
        {
            color = "blue";
        }


        if(type.contains("Ram"))
        {
            board[x][y] = new Ram(x, y, color);
        }
        else if(type.contains("Biz"))
        {
            board[x][y] = new Biz(x, y, color);
        }
        else if(type.contains("Tor"))
        {
            board[x][y] = new Tor(x, y, color);
        }
        else if(type.contains("Xor"))
        {
            board[x][y] = new Xor(x, y, color);
        }
        else if(type.contains("Sau"))
        {
            board[x][y] = new Sau(x, y, color);
        }
        else
        {
            board[x][y] = null;
        }
    }

    int[] loadGame()   //Vincent Oong Zhu Pew     //Loads the saved game from database to the board to play
    {
        try
        {
            Scanner readFile = new Scanner(new File("Save.txt"));

            String chess;
            String turnLine = readFile.nextLine();
            int turn = Integer.parseInt(turnLine.split(":")[1].trim());

            String timeLine = readFile.nextLine();
            elapsedTime = Integer.parseInt(timeLine.split(":")[1].trim());

            for(int i = 0; i < row; i++)
            {
                for(int j = 0; j < column; j++)
                {
                    chess = readFile.next();
                    
                    if(chess.equals("Empty"))
                    {
                        board[i][j] = null;
                    }
                    else 
                    {
                        createPiece(i, j, chess);
                    }
                }
            }

            return new int[]{turn, elapsedTime};
        
        } catch (Exception e)
        {
            System.out.println("Error ! Cant Load Game !");
            return new int[]{0, 0};
        }
    }
}