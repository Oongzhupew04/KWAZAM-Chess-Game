import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class Assignment {
    public static void main(String [] args)
    {
        GameModel model = new GameModel();
        GameView view = new GameView();
        GameController controller = new GameController(model, view);   
        
        view.setEventHandler(controller);
    }
}